<?php
/* 
 * emailer form processor
 * sends out the form data as an email
 */
    $Title = 'Translate (beta)';
    $Desc = 'Translates incoming data via Google Translate.';


?>
