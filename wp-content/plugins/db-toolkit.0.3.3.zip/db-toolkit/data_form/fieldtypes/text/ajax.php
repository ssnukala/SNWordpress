<?php
	declare_ajax_functions('text_runCode');
?>