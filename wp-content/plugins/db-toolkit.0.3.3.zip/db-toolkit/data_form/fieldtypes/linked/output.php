<?php
	if($Config['_Linkedfields'][$Field]['Type'] == 'checkbox'){
	

	}

	$Out .= $Data[$Field];

?>