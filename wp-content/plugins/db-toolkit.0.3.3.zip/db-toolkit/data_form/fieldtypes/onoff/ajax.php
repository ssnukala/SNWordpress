<?php
	// Declares 
	declare_ajax_functions('onoff_setValue');
?>