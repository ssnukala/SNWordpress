<?php
	// Declare php function that will be available in the insert/setup element screen
	declare_ajax_functions();
?>