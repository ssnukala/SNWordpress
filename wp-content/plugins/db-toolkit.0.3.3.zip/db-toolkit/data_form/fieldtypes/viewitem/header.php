<?php
if(empty($_SESSION['viewitemFilter'])){
	$_SESSION['viewitemFilter'] = array();	
}

?>