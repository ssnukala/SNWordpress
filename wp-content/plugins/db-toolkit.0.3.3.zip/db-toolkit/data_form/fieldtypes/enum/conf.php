<?php
// Field Types Config| 
$FieldTypeTitle = 'Enum';
$isVisible = true;
$FieldTypes = array();

$FieldTypes['enum'] = array('name' => 'Enum','func' => 'null', 'visible' => true, 'baseType' => 'ENUM( \'\' )');


?>