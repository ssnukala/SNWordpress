<?php
// Field Types Config| 
$FieldTypeTitle = 'Gravatar';
$isVisible = true;
$FieldTypes = array();

$FieldTypes['gravatarimg'] 	= array('name' => 'Gravatar Icon', 'func' => 'gravatar_setup'	, 'visible' => true, 'baseType'  => 'VARCHAR(255)');


?>