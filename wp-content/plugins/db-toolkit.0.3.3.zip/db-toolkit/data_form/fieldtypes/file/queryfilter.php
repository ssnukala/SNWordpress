<?php
//Filters query variables for the field type

?>